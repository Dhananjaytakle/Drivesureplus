import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import satori from 'satori';
import { html } from 'satori-html';
import { Resvg } from '@resvg/resvg-js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const B = {
  cream:'#FBF6EC', card:'#FFFFFF', ink:'#1C1C1C', inkSoft:'#5B564C',
  gold:'#D69A2D', goldSoft:'#F3CE6E', line:'#E7DCC6',
};

const font = (f) => fs.readFileSync(path.join(__dirname,'fonts',f));
const FONTS = [
  { name:'Inter', weight:400, style:'normal', data:font('Inter-Regular.ttf') },
  { name:'Inter', weight:600, style:'normal', data:font('Inter-SemiBold.ttf') },
  { name:'Inter', weight:700, style:'normal', data:font('Inter-Bold.ttf') },
  { name:'Inter', weight:800, style:'normal', data:font('Inter-ExtraBold.ttf') },
  { name:'Playfair', weight:600, style:'normal', data:font('Playfair-SemiBold.ttf') },
  { name:'Playfair', weight:700, style:'normal', data:font('Playfair-Bold.ttf') },
  { name:'Playfair', weight:600, style:'italic', data:font('Playfair-Italic.ttf') },
];

function svgUri(file){
  const p = path.join(__dirname,'assets','illustrations',file);
  return `data:image/svg+xml;base64,${fs.readFileSync(p).toString('base64')}`;
}

function illustration(category){
  const f = path.join(__dirname,'assets','illustrations',`${category}.svg`);
  const fb = path.join(__dirname,'assets','illustrations','car.svg');
  const svg = fs.readFileSync(fs.existsSync(f)?f:fb);
  return `data:image/svg+xml;base64,${svg.toString('base64')}`;
}
const esc = (s='') => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// greedy wrap into lines; respects explicit \n, targets ~contentWidth at given font size
function wrapLines(text, fontSize=76, contentWidth=960, factor=0.52){
  const maxChars = Math.max(8, Math.floor(contentWidth / (fontSize*factor)));
  const out = [];
  for (const para of String(text).split('\n')){
    let line = '';
    for (const w of para.split(/\s+/)){
      const t = line ? line+' '+w : w;
      if (t.length > maxChars && line){ out.push(line); line = w; }
      else line = t;
    }
    if (line) out.push(line);
  }
  return out;
}

function row(b){
  return `<div style="display:flex;align-items:center;background:${B.card};border:2px solid ${B.line};border-radius:22px;padding:18px 26px;margin-top:13px;">`
    + `<div style="display:flex;width:52px;height:52px;border-radius:14px;background:${B.cream};border:2px solid ${B.gold};align-items:center;justify-content:center;">`
    + `<div style="display:flex;width:20px;height:20px;border-radius:6px;background:${B.goldSoft};border:2px solid ${B.gold};"></div></div>`
    + `<div style="display:flex;flex:1;margin-left:22px;font-size:34px;color:${B.ink};font-weight:700;">${esc(b.k)}`
    + `<div style="display:flex;color:${B.inkSoft};font-weight:600;margin-left:12px;">— ${esc(b.v)}</div></div>`
    + `<div style="display:flex;width:44px;height:44px;border-radius:50%;border:3px solid ${B.gold};align-items:center;justify-content:center;color:${B.gold};font-size:30px;font-weight:800;">›</div>`
    + `</div>`;
}

export function buildMarkup(p){
  const bullets = (p.bullets||[]).slice(0,4).map(row).join('');
  return html(
    `<div style="display:flex;flex-direction:column;width:1080px;height:1350px;background:${B.cream};padding:48px 60px;font-family:Inter;">`
    + `<div style="display:flex;align-items:center;">`
      + `<div style="display:flex;width:74px;height:74px;border-radius:20px;background:${B.goldSoft};border:3px solid ${B.ink};align-items:center;justify-content:center;font-size:44px;font-weight:800;color:${B.ink};">D</div>`
      + `<div style="display:flex;margin-left:20px;font-size:44px;font-weight:800;color:${B.ink};">DriveSure`
        + `<div style="display:flex;color:${B.gold};margin-left:10px;">Plus</div></div>`
    + `</div>`
    + `<div style="display:flex;align-self:flex-start;margin-top:34px;align-items:center;border:2px solid ${B.gold};border-radius:40px;padding:12px 26px;">`
      + `<div style="display:flex;width:16px;height:16px;border-radius:50%;background:${B.gold};"></div>`
      + `<div style="display:flex;margin-left:14px;font-size:28px;font-weight:700;color:${B.ink};">${esc(p.pill||'Motor insurance')}</div>`
    + `</div>`
    + `<div style="display:flex;flex-direction:column;margin-top:30px;">`
      + wrapLines(p.headline, 76, 960).map(l =>
          `<div style="display:flex;font-size:76px;line-height:1.08;font-weight:800;color:${B.ink};letter-spacing:-1.5px;">${esc(l)}</div>`
        ).join('')
    + `</div>`
    + `<div style="display:flex;width:120px;height:8px;border-radius:4px;background:${B.gold};margin-top:18px;"></div>`
    + (p.subhead?`<div style="display:flex;margin-top:16px;font-size:34px;color:${B.inkSoft};font-weight:600;">${esc(p.subhead)}</div>`:'')
    + `<div style="display:flex;justify-content:center;margin-top:6px;">`
      + `<img src="${illustration(p.category||'car')}" width="660" height="368" />`
    + `</div>`
    + `<div style="display:flex;flex-direction:column;margin-top:4px;">${bullets}</div>`
    + `<div style="display:flex;flex:1;"></div>`
    + `<div style="display:flex;align-items:center;justify-content:space-between;">`
      + `<div style="display:flex;font-size:26px;color:${B.inkSoft};font-weight:600;">www.drivesureplus.tech</div>`
      + `<div style="display:flex;font-size:26px;color:${B.gold};font-weight:700;">Book a free call ›</div>`
    + `</div>`
    + `</div>`
  );
}

function icon3d(file){
  const p = path.join(__dirname,'assets','3d',file);
  const fb = path.join(__dirname,'assets','3d','shield.png');
  return `data:image/png;base64,${fs.readFileSync(fs.existsSync(p)?p:fb).toString('base64')}`;
}
const eT = (s='') => String(s).replace(/</g,'&lt;').replace(/>/g,'&gt;');

function postRow(r){
  return `<div style="display:flex;align-items:center;background:${B.card};border:2px solid #EBE3D2;border-radius:24px;padding:22px 26px;margin-top:18px;box-shadow:0 12px 26px rgba(0,0,0,0.05);">`
    + `<div style="display:flex;width:104px;height:104px;border-radius:22px;background:linear-gradient(160deg,#FFF8E8,#F6E6BE);align-items:center;justify-content:center;">`
    + `<img src="${icon3d(r.icon||'shield.png')}" width="78" height="78" /></div>`
    + `<div style="display:flex;flex-direction:column;margin-left:24px;flex:1;">`
    + `<div style="display:flex;font-size:37px;font-weight:800;color:${B.ink};letter-spacing:-0.5px;">${eT(r.stat)}</div>`
    + `<div style="display:flex;margin-top:6px;font-size:28px;font-weight:600;color:${B.inkSoft};">${eT(r.sub)}</div>`
    + `</div></div>`;
}

// Default template: information-dense post with 3D icons
export function buildPost(p){
  const rows = (p.rows||[]).slice(0,4).map(postRow).join('');
  return html(
    `<div style="display:flex;flex-direction:column;width:1080px;height:1350px;background:${B.cream};padding:54px 58px;font-family:Inter;">`
    + `<div style="display:flex;align-items:center;justify-content:space-between;">`
      + `<div style="display:flex;align-items:center;">`
        + `<div style="display:flex;width:58px;height:58px;border-radius:16px;background:${B.goldSoft};border:3px solid ${B.ink};align-items:center;justify-content:center;font-size:32px;font-weight:800;color:${B.ink};">D</div>`
        + `<div style="display:flex;margin-left:14px;font-size:34px;font-weight:800;color:${B.ink};">DriveSure<div style="display:flex;color:${B.gold};margin-left:8px;">Plus</div></div>`
      + `</div>`
      + `<div style="display:flex;align-items:center;border:2px solid ${B.gold};border-radius:30px;padding:9px 20px;font-size:24px;font-weight:700;color:${B.ink};">${eT(p.tag||'Insurance')}</div>`
    + `</div>`
    + `<div style="display:flex;flex-direction:column;margin-top:28px;">`
      + wrapLines(p.headline, 66, 960, 0.5).map(l=>`<div style="display:flex;font-size:64px;line-height:1.05;font-weight:800;letter-spacing:-1.5px;color:${B.ink};">${eT(l)}</div>`).join('')
    + `</div>`
    + `<div style="display:flex;width:120px;height:8px;border-radius:4px;background:${B.gold};margin-top:16px;"></div>`
    + rows
    + `<div style="display:flex;flex:1;"></div>`
    + `<div style="display:flex;align-items:center;justify-content:center;background:${B.gold};border-radius:24px;padding:26px 0;box-shadow:0 16px 30px rgba(214,154,45,0.32);">`
      + `<div style="display:flex;font-size:42px;font-weight:800;color:${B.ink};">${eT(p.cta||'Book your free call now')}  \u203a</div></div>`
    + `<div style="display:flex;justify-content:center;margin-top:18px;font-size:26px;font-weight:600;color:${B.inkSoft};">${eT(p.handle||'@drivesureinsure')}<div style="display:flex;color:${B.gold};margin:0 12px;">\u2022</div>${eT(p.whatsapp||'WhatsApp 95523 00233')}</div>`
    + `</div>`
  );
}

export async function renderPng(payload){
  const t = payload.template;
  const markup = t==='cta' ? buildCta(payload)
    : t==='checklist' ? buildMarkup(payload)
    : buildPost(payload);
  const svg = await satori(markup, { width:1080, height:1350, fonts:FONTS });
  const resvg = new Resvg(svg, { fitTo:{ mode:'width', value:1080 } });
  return resvg.render().asPng();
}

function tile(icon, label){
  return `<div style="display:flex;flex:1;align-items:center;background:${B.card};border:2px solid ${B.line};border-radius:20px;padding:16px 18px;margin:0 8px;">`
    + `<div style="display:flex;width:60px;height:60px;border-radius:14px;background:${B.cream};border:2px solid ${B.gold};align-items:center;justify-content:center;">`
    + `<img src="${svgUri(icon)}" width="40" height="40" /></div>`
    + `<div style="display:flex;margin-left:14px;font-size:30px;font-weight:700;color:${B.ink};">${esc(label)}</div>`
    + `</div>`;
}

export function buildCta(p){
  const trust = esc(p.trust || '10,000+ assisted · Since 2017');
  const handle = esc(p.handle || '@drivesureinsure');
  const wa = esc(p.whatsapp || 'WhatsApp 95523 00233');
  const cta = esc(p.cta || 'Book your free call now');
  const headLines = wrapLines(p.headline, 66, 900, 0.50);
  return html(
    `<div style="display:flex;flex-direction:column;width:1080px;height:1350px;background:${B.cream};padding:52px 60px;font-family:Inter;">`
    + `<div style="display:flex;align-items:center;justify-content:space-between;">`
      + `<div style="display:flex;align-items:center;">`
        + `<div style="display:flex;width:72px;height:72px;border-radius:20px;background:${B.goldSoft};border:3px solid ${B.ink};align-items:center;justify-content:center;font-size:42px;font-weight:800;color:${B.ink};">D</div>`
        + `<div style="display:flex;margin-left:18px;font-size:42px;font-weight:800;color:${B.ink};">DriveSure<div style="display:flex;color:${B.gold};margin-left:9px;">Plus</div></div>`
      + `</div>`
      + `<div style="display:flex;align-items:center;border:2px solid ${B.gold};border-radius:40px;padding:10px 22px;font-size:24px;font-weight:700;color:${B.ink};">${trust}</div>`
    + `</div>`
    + `<div style="display:flex;flex-direction:column;margin-top:26px;">`
      + headLines.map(l=>`<div style="display:flex;font-family:Playfair;font-size:66px;line-height:1.1;font-weight:700;color:${B.ink};">${esc(l)}</div>`).join('')
    + `</div>`
    + `<div style="display:flex;width:120px;height:8px;border-radius:4px;background:${B.gold};margin-top:18px;"></div>`
    + `<div style="display:flex;margin-top:16px;font-size:33px;color:${B.inkSoft};font-weight:600;">${esc(p.subhead || 'Talk to a real advisor — before you pay, not after.')}</div>`
    + `<div style="display:flex;flex:1;"></div>`
    + `<div style="display:flex;justify-content:center;">`
      + `<img src="${svgUri('advisor.svg')}" width="360" height="368" /></div>`
    + `<div style="display:flex;flex:1;"></div>`
    + `<div style="display:flex;margin:0 -8px;">`
      + tile('icon-health.svg','Health') + tile('icon-car.svg','Motor') + tile('icon-bike.svg','Two-Wheeler')
    + `</div>`
    + `<div style="display:flex;margin-top:26px;background:${B.gold};border-radius:26px;padding:30px 0;align-items:center;justify-content:center;">`
      + `<div style="display:flex;font-size:44px;font-weight:800;color:${B.ink};letter-spacing:-0.5px;">${cta}  ›</div>`
    + `</div>`
    + `<div style="display:flex;justify-content:center;margin-top:22px;font-size:26px;font-weight:600;color:${B.inkSoft};">`
      + `${handle}<div style="display:flex;color:${B.gold};margin:0 14px;">•</div>${wa}<div style="display:flex;color:${B.gold};margin:0 14px;">•</div>drivesureplus.tech`
    + `</div>`
    + `</div>`
  );
}
