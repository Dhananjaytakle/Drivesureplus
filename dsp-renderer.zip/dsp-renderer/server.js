import express from 'express';
import { renderPng } from './render.js';
import { buildReel } from './reel.js';

const app = express();
app.use(express.json({ limit: '1mb' }));

// simple shared-secret guard (set RENDER_TOKEN in env; leave unset to disable)
const TOKEN = process.env.RENDER_TOKEN || '';
app.use((req, res, next) => {
  if (!TOKEN) return next();
  if (req.path === '/health') return next();
  if (req.get('x-render-token') === TOKEN) return next();
  return res.status(401).json({ error: 'unauthorized' });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

// POST /render  -> image/png
// body: { headline, subhead, pill, category, bullets:[{k,v}], format?: "png"|"base64" }
app.post('/render', async (req, res) => {
  try {
    const p = req.body || {};
    if (!p.headline) return res.status(400).json({ error: 'headline is required' });
    const png = await renderPng(p);
    if (p.format === 'base64') {
      return res.json({ b64: png.toString('base64'), mime: 'image/png' });
    }
    res.set('Content-Type', 'image/png');
    res.send(png);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e && e.message || e) });
  }
});

// POST /reel -> video/mp4 (1080x1920 Reel)
// body: { hook:{hook,sub,icon}, beats:[{title,body,icon}], cta:{cta_title,cta_action,cta_note,icon}, format?:"base64" }
app.post('/reel', async (req, res) => {
  try {
    const p = req.body || {};
    if (!p.hook) return res.status(400).json({ error: 'hook is required' });
    const mp4 = await buildReel(p);
    if (p.format === 'base64') {
      return res.json({ b64: mp4.toString('base64'), mime: 'video/mp4' });
    }
    res.set('Content-Type', 'video/mp4');
    res.send(mp4);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e && e.message || e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`DSP renderer listening on :${PORT}`));
