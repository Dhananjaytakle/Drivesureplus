import express from 'express';
import { renderPng } from './render.js';

const app = express();
app.use(express.json({ limit: '1mb' }));

// simple shared-secret guard (set RENDER_TOKEN in env; leave unset to disable)
const TOKEN = process.env.RENDER_TOKEN || '';
app.use((req, res, next) => {
  if (!TOKEN) return next();
  if (req.path === '/health') return next();
  if (req.get('x-render-token') === TOKEN) return next();
  return res.status(401).json({ error: 'unauthorized' });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

// POST /render  -> image/png
// body: { headline, subhead, pill, category, bullets:[{k,v}], format?: "png"|"base64" }
app.post('/render', async (req, res) => {
  try {
    const p = req.body || {};
    if (!p.headline) return res.status(400).json({ error: 'headline is required' });
    const png = await renderPng(p);
    if (p.format === 'base64') {
      return res.json({ b64: png.toString('base64'), mime: 'image/png' });
    }
    res.set('Content-Type', 'image/png');
    res.send(png);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e && e.message || e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`DSP renderer listening on :${PORT}`));
