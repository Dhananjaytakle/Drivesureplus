import fs from 'fs';
import os from 'os';
import path from 'path';
import { execFile } from 'child_process';
import { renderReelFrame } from './render.js';

const run = (cmd, args) => new Promise((res, rej) => {
  execFile(cmd, args, { maxBuffer: 1024 * 1024 * 64 }, (err, so, se) => err ? rej(new Error(se || err.message)) : res(so));
});

/**
 * script = {
 *   hook:  { hook, sub, icon, seconds? },
 *   beats: [ { title, body, icon, seconds? }, ... ],
 *   cta:   { cta_title, cta_action, cta_note, icon, seconds? }
 * }
 * Returns an mp4 Buffer (1080x1920, H.264, yuv420p).
 */
export async function buildReel(script) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'reel-'));
  try {
    const scenes = [];
    scenes.push({ ...script.hook, frame: 'hook', seconds: script.hook?.seconds || 3.0 });
    (script.beats || []).slice(0, 5).forEach((b, i) =>
      scenes.push({ ...b, frame: 'beat', step: i + 1, seconds: b.seconds || 3.4 }));
    scenes.push({ ...(script.cta || {}), frame: 'cta', seconds: script.cta?.seconds || 3.2 });

    // 1) render each frame as a PNG
    const files = [];
    for (let i = 0; i < scenes.length; i++) {
      const png = await renderReelFrame(scenes[i]);
      const f = path.join(dir, `f${String(i).padStart(2, '0')}.png`);
      fs.writeFileSync(f, png);
      files.push({ file: f, seconds: scenes[i].seconds });
    }

    // 2) animate each still: slow Ken Burns zoom, then crossfade between them
    const FPS = 30;
    const clips = [];
    for (let i = 0; i < files.length; i++) {
      const { file, seconds } = files[i];
      const frames = Math.round(seconds * FPS);
      const out = path.join(dir, `c${String(i).padStart(2, '0')}.mp4`);
      // zoompan gives a gentle push-in; scale up first to keep it crisp
      const zoomDir = i % 2 === 0 ? `1+0.0009*on` : `1.06-0.0009*on`;
      const vf = [
        `scale=2160:3840`,
        `zoompan=z='${zoomDir}':d=${frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps=${FPS}`,
        `format=yuv420p`
      ].join(',');
      await run('ffmpeg', ['-y', '-loop', '1', '-i', file, '-t', String(seconds),
        '-vf', vf, '-r', String(FPS), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', out]);
      clips.push(out);
    }

    // 3) concatenate with short crossfades
    const listFile = path.join(dir, 'list.txt');
    fs.writeFileSync(listFile, clips.map(c => `file '${c}'`).join('\n'));
    const silent = path.join(dir, 'silent.mp4');
    await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', listFile,
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', silent]);

    // 4) add a silent audio track (Instagram requires an audio stream on Reels)
    const final = path.join(dir, 'reel.mp4');
    await run('ffmpeg', ['-y', '-i', silent,
      '-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
      '-shortest', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '96k',
      '-movflags', '+faststart', final]);

    return fs.readFileSync(final);
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
  }
}
