# DriveSurePlus Post Renderer

A tiny HTML-to-image microservice that turns post *data* into an on-brand
1080×1350 PNG (logo lockup, category pill, headline, line-art hero,
checklist cards, footer). Your AI writes the copy; this stamps the design.

No headless Chromium — uses `satori` (HTML→SVG) + `@resvg/resvg-js` (SVG→PNG),
so it's light enough to sit next to n8n on the same VPS.

## Run it on the VPS (Docker)

1. Copy this folder to the VPS, e.g. `/opt/dsp-renderer`.
2. Set a secret and start it:
   ```bash
   cd /opt/dsp-renderer
   echo "RENDER_TOKEN=$(openssl rand -hex 16)" > .env
   docker compose up -d --build
   ```
3. Test:
   ```bash
   curl localhost:3000/health
   curl -o test.png -X POST localhost:3000/render \
     -H "content-type: application/json" \
     -H "x-render-token: <the token from .env>" \
     -d '{"pill":"Motor insurance · Renewal check",
          "headline":"Your renewal is cheaper. What changed?",
          "subhead":"Before you pay, compare what matters.",
          "category":"car",
          "bullets":[{"k":"IDV","v":"Is it sensible?"},
                     {"k":"NCB","v":"Is it correct?"},
                     {"k":"Add-ons","v":"Any useful cover missing?"},
                     {"k":"Deductibles","v":"What will you pay?"}]}'
   ```

## API

`POST /render` → `image/png` (or `{ "b64": "..." }` if you pass `"format":"base64"`)

| field    | type                     | notes                                             |
|----------|--------------------------|---------------------------------------------------|
| headline | string (required)        | auto-wraps; use `\n` to force a line break        |
| subhead  | string                   | one line under the headline                       |
| pill     | string                   | e.g. `"Motor insurance · Renewal check"`          |
| category | car·health·term_life·two_wheeler | picks the hero illustration (default car) |
| bullets  | array of `{k, v}`        | 0–4 checklist rows (`k` bold, `v` muted)          |
| format   | `"png"` (default) or `"base64"` |                                            |

Header `x-render-token` must match `RENDER_TOKEN` (skip if you leave it unset).

Add more heroes by dropping `assets/illustrations/<category>.svg` files in.

## Wiring into the n8n workflow ("DriveSurePlus - AI Social Media Manager")

1. **Gemini prompt** — extend the JSON each post returns with design fields:
   `headline` (short, ≤ ~40 chars), `subhead` (≤ ~8 words),
   `pill` (e.g. "Motor insurance · Renewal check"), and for info posts a
   `bullets` array of 3–4 `{ "k": "...", "v": "..." }`. Keep `caption`,
   `hashtags`, `story_text`, `category`.
2. **Replace the image step** — swap `Generate Post Image (OpenAI)` for an
   HTTP Request node: `POST http://<VPS_IP>:3000/render` (or
   `http://dsp-renderer:3000/render` if on n8n's Docker network),
   header `x-render-token`, JSON body built from the fields above,
   response format **File / Binary**. That binary feeds straight into
   `Post Photo to Facebook` — the old `Prep Image Data` + `Convert Image to
   Binary` + OpenAI cost logging can be dropped (render cost = ₹0).
3. **Activate** — publish the workflow, set Workflow Settings → timezone to
   **Asia/Kolkata** (so the 10:00 trigger is IST), then run once manually
   before trusting the schedule.
